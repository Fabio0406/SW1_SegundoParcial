from . import course
from . import student
from . import parent
from . import teacher
from . import subject
from . import notice  # Nuevo modelo de aviso
from . import notice_attachment  # Modelo para adjuntos
from . import notice_recipient